import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>

      <Person name={"Doe, Jane"} age={45} description={"hair Color:Black"}/>
      <Person name={"Smith, Johne"} age={88} description={"hair Color:Brown"}/>
      <Person name={"Fillmore, Millard"} age={50} description={"hair Color:Brown"}/>
      <Person name={"Smith, Maria"} age={62} description={"hair Color:Brown"}/>

    </>
  )
}

export default App
