import { useState } from 'react'
import './App.css'

function App() {
  return (
    <>
      <h1>Hello Dojo!</h1>
      <h2>Thing I need to do:</h2>
      <ul>
        <li>Learn React</li>
        <li>Climb Mt Everest</li>
        <li>Run a Marathon</li>
        <li>Feed the dogs</li>
      </ul>
    </>
  )
}

export default App
